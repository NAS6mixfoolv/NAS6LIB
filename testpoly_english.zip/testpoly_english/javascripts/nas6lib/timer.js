﻿//Programed by NAS6
//timer.js

var NAS6LIB = function() {
};

var inherits = function(childCtor, parentCtor) {
  Object.setPrototypeOf(childCtor.prototype, parentCtor.prototype);
};



var N6LTimer = function(id) {
  this.typename = "N6LTimer";
  this.ID = id;
  this.enable = false;
  var dt = new Date();
  this.starttime = dt.getTime();
  this.alerm = -1;
  this.alermfunc = 0;

};

//inherits(N6LTimer, NAS6LIB);

  N6LTimer.prototype.start = function() {
    this.enable = true;
    this.reset();
  }
  N6LTimer.prototype.stop = function() {
    this.enable = false;
  }
  N6LTimer.prototype.reset = function() {
    var dt = new Date();
    this.starttime = dt.getTime();
  };
  N6LTimer.prototype.copy = function(src) {
    this.ID = src.ID;
    this.enable = src.enable;
    this.starttime = src.starttime;
    this.alerm = src.alerm;
    this.alermfunc = src.alermfunc;
  };
  N6LTimer.prototype.now = function() {
    if(this.starttime != 0){
      var dt = new Date();
      nowtime = dt.getTime();
      var interval = nowtime - this.starttime;
      return interval;
    }
  };
  N6LTimer.prototype.setalerm = function(func,alm) {
    this.start();
    this.alerm = alm;
    this.alermfunc = func;
  };



var N6LTimerMan = function() {
  this.typename = "N6LTimerMan";
  this.interval = 25;
  this.enable = true;
  this.timer = new Array();
};

//inherits(N6LTimerMan, NAS6LIB);

  N6LTimerMan.prototype.add = function() {
    var l = this.timer.length;
    if(l == 0) this.start();
    this.timer.push(new N6LTimer(l));
    this.timer[l].start();
  };
  N6LTimerMan.prototype.changeinterval = function(int) {
    this.interval = int;
    var me = this;
    setTimeout(function() { TMUpdate(me); }, this.interval);
  };
  N6LTimerMan.prototype.start = function() {
    this.enable = true;
    var me = this;
    setTimeout(function() { TMUpdate(me); }, this.interval);
  };
  N6LTimerMan.prototype.stop = function() {
    this.enable = false;
  };

function TMUpdate(timerman) {
  if(timerman.enable == true){
    for(var m in timerman.timer){
      var tm = timerman.timer[m];
      if(tm.enable == true && 0 <= tm.alerm){
        var now = tm.now();
        if(tm.alerm <= now){
          tm.alerm = -1;
          tm.alermfunc(tm.ID);
        }
      }
    }
    setTimeout(function() { TMUpdate(timerman); }, this.interval);
  }
}
