﻿"./javascripts/x3dom/" フォルダ内に、
jquery-3.7.1.min.js などの jQuery ファイルと、
x3dom.css, x3dom.js, x3dom-full.js などの X3DOM ファイルを配置してください。

また、three.js-r177 や three.js-master のような Three.js のダウンロード済みルートフォルダは、
"threejs" とリネームして "./javascripts/threejs/" フォルダ内に配置してください。

万が一、ファイルが見つからないなどの問題が発生した場合は、
基本的には "https://nas6.net/" のサイトと同じフォルダ構成になっておりますので、
そちらをご参照ください。


Place jQuery files (e.g., jquery-3.7.1.min.js) and X3DOM files (e.g., x3dom.css, x3dom.js, x3dom-full.js) 
into the "./javascripts/x3dom/" folder.

Also, rename the downloaded Three.js root folder (e.g., three.js-r177 or three.js-master) to "threejs" 
and place it inside the "./javascripts/threejs/" folder.

In case you encounter any issues with missing files or require further reference, please note 
that the folder structure is fundamentally the same as "https://nas6.net/".


