﻿Malti domain may be security error at local work.(failure get image file)
No problem if Apache or upload.