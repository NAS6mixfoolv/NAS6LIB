﻿javascriptsフォルダ内にある
x3domフォルダにx3domの各ファイルとjqueryを置いて適切にパスを通してください
threejsフォルダにthreejsファイルと同様にしてください

In the javascripts folder
Put each x3dom file and jquery in the x3dom folder and set the path appropriately. 
Do the same with the threejs file in the threejs folder.

