﻿var chk = false;
var TMan = new N6LTimerMan();  //timer manager//タイマーマネージャー
var x3domRuntime;

var fr = 1000;
var A = new N6LMatrix(4).UnitMat();  //mat view//view回転行列

function chgrotVec(){
  var elm = document.getElementById('rotin');
  var ro = String(elm.value);
  elm = document.getElementById('rot');
  elm.value = ro;
  var rot = new N6LVector().Parse(ro);
  var radioList = document.getElementsByName("INV");
  var dt = [];
  if(radioList[0].checked) {
    A = rot.Matrix();
    A = A.InverseMat(dt);
  }
  else {
    A = rot.Matrix();
  }
  rot = A.Vector();
  elm = document.getElementById('viewp001');
  elm.setAttribute('orientation', rot.ToX3DOM().toString());
  var ea = A.EulerAngle(1,2,3);
  elm = document.getElementById('rotEA');
  var str = String(Math.floor(ea.x[1]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[2]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[3]*(180.0/Math.PI)*fr)/fr);
  elm.value = str;
  var qt = A.Quaternion();
  elm = document.getElementById('rotQT');
  str = 'true,4,'+String(Math.floor(qt.q.x[0]*fr)/fr)+','+String(Math.floor(qt.q.x[1]*fr)/fr)+','+String(Math.floor(qt.q.x[2]*fr)/fr)+','+String(Math.floor(qt.q.x[3]*fr)/fr);
  elm.value = str;
  elm = document.getElementById('rotMT');
  str = 'true,4&#13;true,4,'+String(Math.floor(A.x[0].x[0]*fr)/fr)+','+String(Math.floor(A.x[0].x[1]*fr)/fr)+','+String(Math.floor(A.x[0].x[2]*fr)/fr)+','+String(Math.floor(A.x[0].x[3]*fr)/fr) +
        '&#13;true,4,'+String(Math.floor(A.x[1].x[0]*fr)/fr)+','+String(Math.floor(A.x[1].x[1]*fr)/fr)+','+String(Math.floor(A.x[1].x[2]*fr)/fr)+','+String(Math.floor(A.x[1].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[2].x[0]*fr)/fr)+','+String(Math.floor(A.x[2].x[1]*fr)/fr)+','+String(Math.floor(A.x[2].x[2]*fr)/fr)+','+String(Math.floor(A.x[2].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[3].x[0]*fr)/fr)+','+String(Math.floor(A.x[3].x[1]*fr)/fr)+','+String(Math.floor(A.x[3].x[2]*fr)/fr)+','+String(Math.floor(A.x[3].x[3]*fr)/fr);
  elm.value = str;

  if(radioList[0].checked) {
    A = A.InverseMat(dt);
  }
}

function chgrotEA(){
  var elm = document.getElementById('rotEAin');
  var roEA = String(elm.value);
  elm = document.getElementById('rotEA');
  elm.value = roEA;
  var tk = roEA.split(',');
  var ea = new N6LVector([1,Number(tk[0])*(Math.PI/180.0),Number(tk[1])*(Math.PI/180.0),Number(tk[2])*(Math.PI/180.0)],true);
  var ax = new N6LVector(4,true).UnitVec(1);
  var ay = new N6LVector(4,true).UnitVec(2);
  var az = new N6LVector(4,true).UnitVec(3);
  A = A.UnitMat().RotAxis(ax,ea.x[1]);
  ay = A.GetRow(2);
  A = A.RotAxis(ay,ea.x[2]);
  az = A.GetRow(3);
  A = A.RotAxis(az,ea.x[3]);
  var radioList = document.getElementsByName("INV");
  var rot = A.Vector();
  var dt = [];
  if(radioList[0].checked) {
    A = rot.Matrix();
    A = A.InverseMat(dt);
  }
  else {
    A = rot.Matrix();
  }
  rot = A.Vector();
  elm = document.getElementById('viewp001');
  elm.setAttribute('orientation', rot.ToX3DOM().toString());
  elm = document.getElementById('rot');
  var str = 'true,4,'+String(Math.floor(rot.x[0]*fr)/fr)+','+String(Math.floor(rot.x[1]*fr)/fr)+','+String(Math.floor(rot.x[2]*fr)/fr)+','+String(Math.floor(rot.x[3]*fr)/fr);
  elm.value = str;
  var qt = A.Quaternion();
  elm = document.getElementById('rotQT');
  str = 'true,4,'+String(Math.floor(qt.q.x[0]*fr)/fr)+','+String(Math.floor(qt.q.x[1]*fr)/fr)+','+String(Math.floor(qt.q.x[2]*fr)/fr)+','+String(Math.floor(qt.q.x[3]*fr)/fr);
  elm.value = str;
  elm = document.getElementById('rotMT');
  str = 'true,4&#13;true,4,'+String(Math.floor(A.x[0].x[0]*fr)/fr)+','+String(Math.floor(A.x[0].x[1]*fr)/fr)+','+String(Math.floor(A.x[0].x[2]*fr)/fr)+','+String(Math.floor(A.x[0].x[3]*fr)/fr) +
        '&#13;true,4,'+String(Math.floor(A.x[1].x[0]*fr)/fr)+','+String(Math.floor(A.x[1].x[1]*fr)/fr)+','+String(Math.floor(A.x[1].x[2]*fr)/fr)+','+String(Math.floor(A.x[1].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[2].x[0]*fr)/fr)+','+String(Math.floor(A.x[2].x[1]*fr)/fr)+','+String(Math.floor(A.x[2].x[2]*fr)/fr)+','+String(Math.floor(A.x[2].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[3].x[0]*fr)/fr)+','+String(Math.floor(A.x[3].x[1]*fr)/fr)+','+String(Math.floor(A.x[3].x[2]*fr)/fr)+','+String(Math.floor(A.x[3].x[3]*fr)/fr);
  elm.value = str;
  if(radioList[0].checked) {
    A = A.InverseMat(dt);
  }
}

function chgrotQT(){
  var elm = document.getElementById('rotQTin');
  var ro = String(elm.value);
  elm = document.getElementById('rotQT');
  elm.value = ro;
  var qt = new N6LQuaternion().Parse(ro);
  var dt = [];
  A = qt.Matrix();
  var rot = A.Vector();
  var radioList = document.getElementsByName("INV");
  if(radioList[0].checked) {
    A = rot.Matrix();
    A = A.InverseMat(dt);
  }
  else {
    A = rot.Matrix();
  }
  rot = A.Vector();
  elm = document.getElementById('viewp001');
  elm.setAttribute('orientation', rot.ToX3DOM().toString());
  elm = document.getElementById('rot');
  var str = 'true,4,'+String(Math.floor(rot.x[0]*fr)/fr)+','+String(Math.floor(rot.x[1]*fr)/fr)+','+String(Math.floor(rot.x[2]*fr)/fr)+','+String(Math.floor(rot.x[3]*fr)/fr);
  elm.value = str;
  var ea = A.EulerAngle(1,2,3);
  elm = document.getElementById('rotEA');
  str = String(Math.floor(ea.x[1]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[2]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[3]*(180.0/Math.PI)*fr)/fr);
  elm.value = str;
  elm = document.getElementById('rotQT');
  str = 'true,4,'+String(Math.floor(qt.q.x[0]*fr)/fr)+','+String(Math.floor(qt.q.x[1]*fr)/fr)+','+String(Math.floor(qt.q.x[2]*fr)/fr)+','+String(Math.floor(qt.q.x[3]*fr)/fr);
  elm.value = str;
  elm = document.getElementById('rotMT');
  str = 'true,4&#13;true,4,'+String(Math.floor(A.x[0].x[0]*fr)/fr)+','+String(Math.floor(A.x[0].x[1]*fr)/fr)+','+String(Math.floor(A.x[0].x[2]*fr)/fr)+','+String(Math.floor(A.x[0].x[3]*fr)/fr) +
        '&#13;true,4,'+String(Math.floor(A.x[1].x[0]*fr)/fr)+','+String(Math.floor(A.x[1].x[1]*fr)/fr)+','+String(Math.floor(A.x[1].x[2]*fr)/fr)+','+String(Math.floor(A.x[1].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[2].x[0]*fr)/fr)+','+String(Math.floor(A.x[2].x[1]*fr)/fr)+','+String(Math.floor(A.x[2].x[2]*fr)/fr)+','+String(Math.floor(A.x[2].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[3].x[0]*fr)/fr)+','+String(Math.floor(A.x[3].x[1]*fr)/fr)+','+String(Math.floor(A.x[3].x[2]*fr)/fr)+','+String(Math.floor(A.x[3].x[3]*fr)/fr);
  elm.value = str;

  if(radioList[0].checked) {
    A = A.InverseMat(dt);
  }
}

function chgrotMT(){
  var elm = document.getElementById('rotMTin');
  var ro = String(elm.value);
  elm = document.getElementById('rotMT');
  elm.value = ro;
  ro = ro.replace(/\n/g, " ");
  A = new N6LMatrix().Parse(ro);
  var radioList = document.getElementsByName("INV");
  var dt = [];
  var rot = A.Vector();
  if(radioList[0].checked) {
    A = rot.Matrix();
    A = A.InverseMat(dt);
  }
  else {
    A = rot.Matrix();
  }
  rot = A.Vector();
  elm = document.getElementById('viewp001');
  elm.setAttribute('orientation', rot.ToX3DOM().toString());
  elm = document.getElementById('rot');
  var str = 'true,4,'+String(Math.floor(rot.x[0]*fr)/fr)+','+String(Math.floor(rot.x[1]*fr)/fr)+','+String(Math.floor(rot.x[2]*fr)/fr)+','+String(Math.floor(rot.x[3]*fr)/fr);
  elm.value = str;
  var ea = A.EulerAngle(1,2,3);
  elm = document.getElementById('rotEA');
  var str = String(Math.floor(ea.x[1]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[2]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[3]*(180.0/Math.PI)*fr)/fr);
  elm.value = str;
  var qt = A.Quaternion();
  elm = document.getElementById('rotQT');
  str = 'true,4,'+String(Math.floor(qt.q.x[0]*fr)/fr)+','+String(Math.floor(qt.q.x[1]*fr)/fr)+','+String(Math.floor(qt.q.x[2]*fr)/fr)+','+String(Math.floor(qt.q.x[3]*fr)/fr);
  elm.value = str;
  elm = document.getElementById('rotMT');
  str = 'true,4&#13;true,4,'+String(Math.floor(A.x[0].x[0]*fr)/fr)+','+String(Math.floor(A.x[0].x[1]*fr)/fr)+','+String(Math.floor(A.x[0].x[2]*fr)/fr)+','+String(Math.floor(A.x[0].x[3]*fr)/fr) +
        '&#13;true,4,'+String(Math.floor(A.x[1].x[0]*fr)/fr)+','+String(Math.floor(A.x[1].x[1]*fr)/fr)+','+String(Math.floor(A.x[1].x[2]*fr)/fr)+','+String(Math.floor(A.x[1].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[2].x[0]*fr)/fr)+','+String(Math.floor(A.x[2].x[1]*fr)/fr)+','+String(Math.floor(A.x[2].x[2]*fr)/fr)+','+String(Math.floor(A.x[2].x[3]*fr)/fr) +  
        '&#13;true,4,'+String(Math.floor(A.x[3].x[0]*fr)/fr)+','+String(Math.floor(A.x[3].x[1]*fr)/fr)+','+String(Math.floor(A.x[3].x[2]*fr)/fr)+','+String(Math.floor(A.x[3].x[3]*fr)/fr);
  elm.value = str;

  if(radioList[0].checked) {
    A = A.InverseMat(dt);
  }
}


function copy(){
  var elm = document.getElementById('rot');
  var str = String(elm.value);
  elm = document.getElementById('rotin');
  elm.value = str;
  elm = document.getElementById('rotEA');
  str = String(elm.value);
  elm = document.getElementById('rotEAin');
  elm.value = str;
  var elm = document.getElementById('rotQT');
  var str = String(elm.value);
  elm = document.getElementById('rotQTin');
  elm.value = str;
  var elm = document.getElementById('rotMT');
  var str = String(elm.value);
  elm = document.getElementById('rotMTin');
  elm.value = str;
}

jQuery(document).ready(function(){
  TMan.add();
  TMan.timer[0].setalerm(function() { GLoop(0); }, 50);  //set main loop//メインループセット
});

var be = true;
function input(){
  var str;
  if(be) str = 'rgb(255,255,255)';
  else str = 'rgb(136,136,136)';
  var elm = document.getElementById('rotin');
  elm.style.backgroundColor = str;
  elm = document.getElementById('rotEAin');
  elm.style.backgroundColor = str;
  elm = document.getElementById('rotQTin');
  elm.style.backgroundColor = str;
  elm = document.getElementById('rotMTin');
  elm.style.backgroundColor = str;
  if(be) be = false;
  else be = true;
  KeyB.setenable(be);
}

//main loop//メインループ
function GLoop(id){
  if(x3domRuntime == undefined) {
    x3domRuntime = document.getElementById('x3dabs').runtime; 
    TMan.timer[id].setalerm(function() { GLoop(id); }, 50);  //reset main loop//メインループ再セット
    return;
  }

  var elm = document.getElementById('viewp001');

  var SWM = x3domRuntime.viewMatrix().inverse(); //ワールド回転行列取得
  A = new N6LMatrix().FromX3DOM(SWM);

  var radioList = document.getElementsByName("INV");
  var dt = [];
  var rot = A.Vector();
  if(radioList[0].checked) {
    A = rot.Matrix();
    A = A.InverseMat(dt);
  }
  else {
    A = rot.Matrix();
  }



  var ea = A.EulerAngle(1,2,3);
  var elm = document.getElementById('rotEA');
  var str = String(Math.floor(ea.x[1]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[2]*(180.0/Math.PI)*fr)/fr)+','+String(Math.floor(ea.x[3]*(180.0/Math.PI)*fr)/fr);
  elm.value = str;

  rot = A.Vector();
  elm = document.getElementById('rot');
  str = 'true,4,'+String(Math.floor(rot.x[0]*fr)/fr)+','+String(Math.floor(rot.x[1]*fr)/fr)+','+String(Math.floor(rot.x[2]*fr)/fr)+','+String(Math.floor(rot.x[3]*fr)/fr);
  elm.value = str;

  var qt = A.Quaternion();
  elm = document.getElementById('rotQT');
  str = 'true,4,'+String(Math.floor(qt.q.x[0]*fr)/fr)+','+String(Math.floor(qt.q.x[1]*fr)/fr)+','+String(Math.floor(qt.q.x[2]*fr)/fr)+','+String(Math.floor(qt.q.x[3]*fr)/fr);
  elm.value = str;

  elm = document.getElementById('rotMT');
  str = 'true,4\ntrue,4,'+String(Math.floor(A.x[0].x[0]*fr)/fr)+','+String(Math.floor(A.x[0].x[1]*fr)/fr)+','+String(Math.floor(A.x[0].x[2]*fr)/fr)+','+String(Math.floor(A.x[0].x[3]*fr)/fr) +
        '\ntrue,4,'+String(Math.floor(A.x[1].x[0]*fr)/fr)+','+String(Math.floor(A.x[1].x[1]*fr)/fr)+','+String(Math.floor(A.x[1].x[2]*fr)/fr)+','+String(Math.floor(A.x[1].x[3]*fr)/fr) +  
        '\ntrue,4,'+String(Math.floor(A.x[2].x[0]*fr)/fr)+','+String(Math.floor(A.x[2].x[1]*fr)/fr)+','+String(Math.floor(A.x[2].x[2]*fr)/fr)+','+String(Math.floor(A.x[2].x[3]*fr)/fr) +  
        '\ntrue,4,'+String(Math.floor(A.x[3].x[0]*fr)/fr)+','+String(Math.floor(A.x[3].x[1]*fr)/fr)+','+String(Math.floor(A.x[3].x[2]*fr)/fr)+','+String(Math.floor(A.x[3].x[3]*fr)/fr);
  elm.innerText = str;
  elm.value = str;


  if(radioList[0].checked) {
    ;
  }
  else {
    A = A.InverseMat(dt);
  }



  TMan.timer[id].setalerm(function() { GLoop(id); }, 50);  //reset main loop//メインループ再セット
}

//キー入力
function chkKeyBoard(){
  var b = false;
  var p = 0.0;
  var y = 0.0;
  var r = 0.0;
  var ad = 0.05;
  if(KeyB.keystate[KeyB.indexof(KeyB.ToReal('VK_N2'))]) {//N2Key
    b = true;
    p -= ad;
  }
  if(KeyB.keystate[KeyB.indexof(KeyB.ToReal('VK_N8'))]) {//N8Key
    b = true;
    p += ad;
  }
  if(KeyB.keystate[KeyB.indexof(KeyB.ToReal('VK_N4'))]) {//N4Key
    b = true;
    y -= ad;
  }
  if(KeyB.keystate[KeyB.indexof(KeyB.ToReal('VK_N6'))]) {//N6Key
    b = true;
    y += ad;
  }
  if(KeyB.keystate[KeyB.indexof(KeyB.ToReal('VK_N1'))]) {//N1Key
    b = true;
    r -= ad;
  }
  if(KeyB.keystate[KeyB.indexof(KeyB.ToReal('VK_N3'))]) {//N3Key
    b = true;
    r += ad;
  }
  if(b) {
    var dt = [];
    var rot = A.Vector();
    A = rot.Matrix();
    A = A.InverseMat(dt);
    var wpyr = new N6LVector([1, p, y, r], true);
    var outmat = [];
    var outv = [];
    A = A.MoveMat(outmat, outv, new N6LVector(4, true).ZeroVec(), wpyr, 0, 0, 0, 0); //目的の関数
    rot = A.Vector();
    var elm = document.getElementById('viewp001');
    elm.setAttribute('orientation', rot.ToX3DOM().toString());
    A = A.InverseMat(dt);
  }
};

